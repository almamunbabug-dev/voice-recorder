# Voice Recorder (Android)

Native Android voice recorder. Android 8.0+ (API 26).

## Features
- High quality AAC (.m4a): Low 64k / Standard 128k / High 192k / Studio 320k stereo
- Mic modes: Standard, Voice (clear speech), Raw (no processing), Video mic
- Pause / resume, discard, live level meter, precise timer
- Keeps recording with the screen off (foreground service)
- Notification controls: Pause / Resume / Stop & save
- Recordings list with date, duration and size; free space shown
- Player: seek, -10s / +10s, speed 0.75x-2x
- Rename, share (WhatsApp, Drive...), save to phone Music folder, delete

## Build
Push to GitHub: the workflow in `.github/workflows/build.yml` builds the APK and
publishes it under Releases (`VoiceRecorder.apk`).
