package com.almamun.voicerecorder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Scrolling bar meter that shows the live input level. */
public class LevelView extends View {
    private final float[] values = new float[90];
    private int head = 0;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color = 0xFF4A525C;

    public LevelView(Context c) {
        super(c);
        paint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setActive(boolean active) {
        color = active ? 0xFFFF4D5E : 0xFF4A525C;
        invalidate();
    }

    public void push(float v) {
        values[head] = Math.max(0f, Math.min(1f, v));
        head = (head + 1) % values.length;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        int n = values.length;
        float w = getWidth(), h = getHeight();
        float step = w / n;
        float mid = h / 2f;
        paint.setStrokeWidth(step * 0.55f);
        paint.setColor(color);
        for (int i = 0; i < n; i++) {
            float v = values[(head + i) % n];
            float half = Math.max(step * 0.25f, v * h * 0.45f);
            float x = step * i + step / 2f;
            c.drawLine(x, mid - half, x, mid + half, paint);
        }
    }
}
