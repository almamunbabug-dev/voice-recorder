package com.almamun.voicerecorder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity implements RecorderService.Listener {
    private static final int C_BG = 0xFF0F1216, C_CARD = 0xFF181D24, C_INK = 0xFFF2F4F7,
            C_MUTED = 0xFF8A94A3, C_RED = 0xFFFF4D5E, C_LINE = 0xFF262C35;
    private static final float[] SPEEDS = {1f, 1.25f, 1.5f, 2f, 0.75f};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private LevelView level;
    private TextView timer, status, recBtn, stopBtn, discardBtn, summary;
    private Spinner qualitySpin, sourceSpin;
    private ListView list;
    private final List<File> files = new ArrayList<>();
    private final Map<String, Long> durations = new HashMap<>();
    private RecAdapter adapter;

    private LinearLayout player;
    private TextView pName, pTime, pPlay, pSpeed;
    private SeekBar pSeek;
    private MediaPlayer mp;
    private File playing;
    private int speedIdx = 0;
    private boolean userSeeking = false;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView circleButton(String label, int sizeDp, int bg, float sp) {
        TextView b = text(label, sp, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(oval(bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        lp.setMargins(dp(14), 0, dp(14), 0);
        b.setLayoutParams(lp);
        b.setClickable(true);
        return b;
    }

    private TextView pill(String label) {
        TextView b = text(label, 15, C_INK, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(C_LINE, 22));
        b.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44));
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);
        b.setMinWidth(dp(48));
        b.setClickable(true);
        return b;
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));

        root.addView(text("Voice Recorder", 22, C_INK, true));

        // Live level meter
        level = new LevelView(this);
        level.setBackground(round(C_CARD, 18));
        LinearLayout.LayoutParams lvp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110));
        lvp.setMargins(0, dp(12), 0, 0);
        level.setPadding(dp(10), 0, dp(10), 0);
        root.addView(level, lvp);

        timer = text("00:00.0", 50, C_INK, false);
        timer.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        timer.setGravity(Gravity.CENTER);
        root.addView(timer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = text("Ready", 14, C_MUTED, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Settings row
        LinearLayout settings = new LinearLayout(this);
        settings.setOrientation(LinearLayout.HORIZONTAL);
        qualitySpin = spinner(new String[]{"Low · 64 kbps", "Standard · 128 kbps", "High · 192 kbps", "Studio · 320 kbps stereo"},
                prefs.getInt("quality", 2), "quality");
        sourceSpin = spinner(new String[]{"Standard mic", "Voice (clear speech)", "Raw (no processing)", "Video mic"},
                prefs.getInt("source", 0), "source");
        LinearLayout.LayoutParams sp1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        sp1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        sp2.setMargins(dp(6), 0, 0, 0);
        settings.addView(qualitySpin, sp1);
        settings.addView(sourceSpin, sp2);
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        setLp.setMargins(0, dp(12), 0, 0);
        root.addView(settings, setLp);

        // Controls
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        discardBtn = circleButton("✕", 56, C_LINE, 20);
        recBtn = circleButton("●", 84, C_RED, 30);
        stopBtn = circleButton("■", 56, C_LINE, 20);
        controls.addView(discardBtn);
        controls.addView(recBtn);
        controls.addView(stopBtn);
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cLp.setMargins(0, dp(16), 0, dp(14));
        root.addView(controls, cLp);

        recBtn.setOnClickListener(v -> onRecordTap());
        stopBtn.setOnClickListener(v -> sendToService(RecorderService.ACTION_STOP));
        discardBtn.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Discard this recording?")
                .setMessage("The current recording will be deleted.")
                .setPositiveButton("Discard", (d, w) -> sendToService(RecorderService.ACTION_DISCARD))
                .setNegativeButton("Keep recording", null)
                .show());

        // List header
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text("Recordings", 17, C_INK, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        summary = text("", 12, C_MUTED, false);
        head.addView(summary);
        root.addView(head);

        // List
        FrameLayout listBox = new FrameLayout(this);
        list = new ListView(this);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        TextView empty = text("No recordings yet.\nTap the red button to start.", 14, C_MUTED, false);
        empty.setGravity(Gravity.CENTER);
        listBox.addView(list);
        listBox.addView(empty, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        list.setEmptyView(empty);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        listLp.setMargins(0, dp(6), 0, 0);
        root.addView(listBox, listLp);
        adapter = new RecAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> togglePlay(files.get(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> {
            showMenu(v, files.get(pos));
            return true;
        });

        root.addView(buildPlayer());
        setContentView(root);
    }

    private Spinner spinner(String[] items, int sel, String key) {
        Spinner s = new Spinner(this, Spinner.MODE_DROPDOWN);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setBackground(round(C_CARD, 12));
        s.setPadding(dp(10), 0, dp(10), 0);
        s.setSelection(Math.max(0, Math.min(items.length - 1, sel)));
        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prefs.edit().putInt(key, position).apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        return s;
    }

    private View buildPlayer() {
        player = new LinearLayout(this);
        player.setOrientation(LinearLayout.VERTICAL);
        player.setBackground(round(C_CARD, 18));
        player.setPadding(dp(14), dp(10), dp(14), dp(10));
        player.setVisibility(View.GONE);

        pName = text("", 14, C_INK, true);
        pName.setSingleLine(true);
        pName.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        player.addView(pName);

        pSeek = new SeekBar(this);
        pSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) pTime.setText(Util.fmt(progress) + " / " + Util.fmt(sb.getMax()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) { userSeeking = true; }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                userSeeking = false;
                if (mp != null) mp.seekTo(sb.getProgress());
            }
        });
        player.addView(pSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        pTime = text("00:00 / 00:00", 13, C_MUTED, false);
        row.addView(pTime, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView back = pill("−10");
        pPlay = pill("❚❚");
        TextView fwd = pill("+10");
        pSpeed = pill("1x");
        TextView close = pill("✕");
        row.addView(back);
        row.addView(pPlay);
        row.addView(fwd);
        row.addView(pSpeed);
        row.addView(close);
        player.addView(row);

        back.setOnClickListener(v -> skip(-10000));
        fwd.setOnClickListener(v -> skip(10000));
        pPlay.setOnClickListener(v -> {
            if (playing != null) togglePlay(playing);
        });
        pSpeed.setOnClickListener(v -> {
            speedIdx = (speedIdx + 1) % SPEEDS.length;
            pSpeed.setText(speedLabel());
            if (mp != null && mp.isPlaying()) applySpeed();
        });
        close.setOnClickListener(v -> stopPlayback());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, 0);
        player.setLayoutParams(lp);
        return player;
    }

    private String speedLabel() {
        float s = SPEEDS[speedIdx];
        return (s == (int) s ? String.valueOf((int) s) : String.valueOf(s)) + "x";
    }

    // ---------- Recording ----------

    private void onRecordTap() {
        int st = RecorderService.state;
        if (st == RecorderService.RECORDING) {
            sendToService(RecorderService.ACTION_PAUSE);
        } else if (st == RecorderService.PAUSED) {
            sendToService(RecorderService.ACTION_RESUME);
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                List<String> perms = new ArrayList<>();
                perms.add(Manifest.permission.RECORD_AUDIO);
                if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS);
                requestPermissions(perms.toArray(new String[0]), 1);
                return;
            }
            startRecording();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != 1) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecording();
        } else {
            Toast.makeText(this, "Microphone permission is needed to record", Toast.LENGTH_LONG).show();
        }
    }

    private void startRecording() {
        stopPlayback();
        Intent i = new Intent(this, RecorderService.class)
                .setAction(RecorderService.ACTION_START)
                .putExtra(RecorderService.EXTRA_QUALITY, qualitySpin.getSelectedItemPosition())
                .putExtra(RecorderService.EXTRA_SOURCE, sourceSpin.getSelectedItemPosition());
        startForegroundService(i);
    }

    private void sendToService(String action) {
        if (RecorderService.state == RecorderService.IDLE) return;
        startService(new Intent(this, RecorderService.class).setAction(action));
    }

    @Override
    public void onRecorderChanged() {
        handler.post(() -> {
            updateControls();
            if (RecorderService.state == RecorderService.IDLE) refreshList();
        });
    }

    private void updateControls() {
        int st = RecorderService.state;
        boolean idle = st == RecorderService.IDLE;
        recBtn.setText(st == RecorderService.RECORDING ? "❚❚" : "●");
        recBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, st == RecorderService.RECORDING ? 26 : 30);
        stopBtn.setAlpha(idle ? 0.35f : 1f);
        discardBtn.setAlpha(idle ? 0.35f : 1f);
        stopBtn.setEnabled(!idle);
        discardBtn.setEnabled(!idle);
        qualitySpin.setEnabled(idle);
        sourceSpin.setEnabled(idle);
        qualitySpin.setAlpha(idle ? 1f : 0.5f);
        sourceSpin.setAlpha(idle ? 1f : 0.5f);
        level.setActive(st == RecorderService.RECORDING);
        if (st == RecorderService.RECORDING) {
            status.setText("Recording · " + qualitySpin.getSelectedItem());
            status.setTextColor(C_RED);
        } else if (st == RecorderService.PAUSED) {
            status.setText("Paused · tap ● to continue, ■ to save");
            status.setTextColor(C_MUTED);
        } else {
            status.setText("Ready · keeps recording with the screen off");
            status.setTextColor(C_MUTED);
            timer.setText("00:00.0");
        }
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            int st = RecorderService.state;
            if (st != RecorderService.IDLE) timer.setText(Util.fmtTenths(RecorderService.elapsedMs()));
            if (st == RecorderService.RECORDING) {
                float a = RecorderService.amplitude() / 32767f;
                level.push((float) Math.sqrt(Math.max(0f, a)));
            } else if (st == RecorderService.IDLE) {
                level.push(0f);
            }
            if (mp != null && !userSeeking) {
                try {
                    int pos = mp.getCurrentPosition();
                    pSeek.setProgress(pos);
                    pTime.setText(Util.fmt(pos) + " / " + Util.fmt(pSeek.getMax()));
                } catch (IllegalStateException ignored) { }
            }
            handler.postDelayed(this, 50);
        }
    };

    // ---------- List ----------

    private void refreshList() {
        files.clear();
        File[] arr = RecorderService.dir(this).listFiles((d, name) -> name.toLowerCase(Locale.US).endsWith(".m4a"));
        if (arr != null) {
            Arrays.sort(arr, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            String active = RecorderService.state != RecorderService.IDLE ? RecorderService.currentPath : null;
            for (File f : arr) {
                // Skip the file that is still being written
                if (f.getAbsolutePath().equals(active)) continue;
                files.add(f);
            }
        }
        long total = 0;
        for (File f : files) total += f.length();
        long free = RecorderService.dir(this).getUsableSpace();
        summary.setText(files.size() + " · " + Util.size(total) + " · " + Util.size(free) + " free");
        adapter.notifyDataSetChanged();
    }

    private long durationOf(File f) {
        String key = f.getAbsolutePath() + ":" + f.lastModified();
        Long cached = durations.get(key);
        if (cached != null) return cached;
        long d = 0;
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(f.getAbsolutePath());
            String s = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (s != null) d = Long.parseLong(s);
        } catch (Exception ignored) {
        } finally {
            try { r.release(); } catch (Exception ignored) { }
        }
        durations.put(key, d);
        return d;
    }

    private class RecAdapter extends BaseAdapter {
        private final SimpleDateFormat df = new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.US);

        @Override public int getCount() { return files.size(); }
        @Override public Object getItem(int i) { return files.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            TextView name, meta;
            if (convert == null) {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(14), dp(11), dp(14), dp(11));
                name = text("", 15, C_INK, true);
                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                meta = text("", 12, C_MUTED, false);
                row.addView(name);
                row.addView(meta);
                row.setTag(new TextView[]{name, meta});
            } else {
                row = (LinearLayout) convert;
                TextView[] t = (TextView[]) row.getTag();
                name = t[0];
                meta = t[1];
            }
            File f = files.get(pos);
            boolean isPlaying = f.equals(playing);
            String n = f.getName();
            name.setText((isPlaying ? "▶  " : "") + n.substring(0, n.length() - 4));
            name.setTextColor(isPlaying ? C_RED : C_INK);
            meta.setText(df.format(new Date(f.lastModified())) + "  ·  " + Util.fmt(durationOf(f)) + "  ·  " + Util.size(f.length()));
            row.setBackground(round(isPlaying ? 0xFF221A1E : C_CARD, 14));
            ensureLayoutParams(row);
            return row;
        }

        private void ensureLayoutParams(View row) {
            ViewGroup.LayoutParams lp = row.getLayoutParams();
            if (lp == null) {
                row.setLayoutParams(new android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        }
    }

    private void showMenu(View anchor, File f) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Play");
        m.getMenu().add(0, 2, 1, "Rename");
        m.getMenu().add(0, 3, 2, "Share (WhatsApp, Drive, etc.)");
        m.getMenu().add(0, 4, 3, "Save to phone Music folder");
        m.getMenu().add(0, 5, 4, "Delete");
        m.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: togglePlay(f); break;
                case 2: rename(f); break;
                case 3: share(f); break;
                case 4: exportToMusic(f); break;
                case 5: confirmDelete(f); break;
                default: break;
            }
            return true;
        });
        m.show();
    }

    private void rename(File f) {
        String base = f.getName().substring(0, f.getName().length() - 4);
        EditText et = new EditText(this);
        et.setText(base);
        et.setSelectAllOnFocus(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        box.addView(et);
        new AlertDialog.Builder(this)
                .setTitle("Rename recording")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String n = et.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (n.isEmpty()) return;
                    File nf = new File(f.getParentFile(), n + ".m4a");
                    if (nf.exists()) {
                        Toast.makeText(this, "A recording with that name already exists", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (f.equals(playing)) stopPlayback();
                    long mod = f.lastModified();
                    if (f.renameTo(nf)) {
                        nf.setLastModified(mod);
                        refreshList();
                    } else {
                        Toast.makeText(this, "Rename failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void share(File f) {
        try {
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent s = new Intent(Intent.ACTION_SEND)
                    .setType("audio/mp4")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(s, "Share recording"));
        } catch (Exception e) {
            Toast.makeText(this, "Could not share this file", Toast.LENGTH_SHORT).show();
        }
    }

    private void exportToMusic(File f) {
        if (Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "On this Android version, use Share to save the file", Toast.LENGTH_LONG).show();
            return;
        }
        ContentValues v = new ContentValues();
        v.put(MediaStore.Audio.Media.DISPLAY_NAME, f.getName());
        v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
        v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Voice Recorder");
        v.put(MediaStore.Audio.Media.IS_PENDING, 1);
        Uri collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        Uri item = null;
        try {
            item = getContentResolver().insert(collection, v);
            if (item == null) throw new IllegalStateException("insert failed");
            try (InputStream in = new FileInputStream(f);
                 OutputStream out = getContentResolver().openOutputStream(item)) {
                if (out == null) throw new IllegalStateException("no stream");
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            v.clear();
            v.put(MediaStore.Audio.Media.IS_PENDING, 0);
            getContentResolver().update(item, v, null, null);
            Toast.makeText(this, "Saved to Music/Voice Recorder", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            if (item != null) {
                try { getContentResolver().delete(item, null, null); } catch (Exception ignored) { }
            }
            Toast.makeText(this, "Could not save to the Music folder", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmDelete(File f) {
        new AlertDialog.Builder(this)
                .setTitle("Delete recording?")
                .setMessage(f.getName() + "\nThis cannot be undone.")
                .setPositiveButton("Delete", (d, w) -> {
                    if (f.equals(playing)) stopPlayback();
                    if (!f.delete()) Toast.makeText(this, "Delete failed", Toast.LENGTH_SHORT).show();
                    refreshList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Playback ----------

    private void togglePlay(File f) {
        if (RecorderService.state != RecorderService.IDLE) {
            Toast.makeText(this, "Stop the current recording first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mp != null && f.equals(playing)) {
            if (mp.isPlaying()) {
                mp.pause();
                pPlay.setText("▶");
            } else {
                mp.start();
                applySpeed();
                pPlay.setText("❚❚");
            }
            return;
        }
        stopPlayback();
        try {
            mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.prepare();
            mp.setOnCompletionListener(p -> {
                pPlay.setText("▶");
                pSeek.setProgress(pSeek.getMax());
            });
            playing = f;
            pSeek.setMax(mp.getDuration());
            pSeek.setProgress(0);
            String n = f.getName();
            pName.setText(n.substring(0, n.length() - 4));
            pSpeed.setText(speedLabel());
            player.setVisibility(View.VISIBLE);
            mp.start();
            applySpeed();
            pPlay.setText("❚❚");
        } catch (Exception e) {
            stopPlayback();
            Toast.makeText(this, "Cannot play this file", Toast.LENGTH_SHORT).show();
        }
        adapter.notifyDataSetChanged();
    }

    private void applySpeed() {
        if (mp == null) return;
        try {
            mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(SPEEDS[speedIdx]));
        } catch (Exception ignored) { }
    }

    private void skip(int ms) {
        if (mp == null) return;
        try {
            int pos = Math.max(0, Math.min(mp.getDuration(), mp.getCurrentPosition() + ms));
            mp.seekTo(pos);
            pSeek.setProgress(pos);
        } catch (IllegalStateException ignored) { }
    }

    private void stopPlayback() {
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) { }
            mp.release();
            mp = null;
        }
        playing = null;
        if (player != null) player.setVisibility(View.GONE);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    // ---------- Lifecycle ----------

    @Override
    protected void onResume() {
        super.onResume();
        RecorderService.listener = this;
        updateControls();
        refreshList();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    @Override
    protected void onDestroy() {
        if (RecorderService.listener == this) RecorderService.listener = null;
        stopPlayback();
        super.onDestroy();
    }
}
