package com.almamun.voicerecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.SystemClock;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Foreground service that owns the MediaRecorder, so recording keeps going with the screen off. */
public class RecorderService extends Service {
    public static final String ACTION_START = "com.almamun.voicerecorder.START";
    public static final String ACTION_PAUSE = "com.almamun.voicerecorder.PAUSE";
    public static final String ACTION_RESUME = "com.almamun.voicerecorder.RESUME";
    public static final String ACTION_STOP = "com.almamun.voicerecorder.STOP";
    public static final String ACTION_DISCARD = "com.almamun.voicerecorder.DISCARD";
    public static final String EXTRA_QUALITY = "quality";
    public static final String EXTRA_SOURCE = "source";

    public static final int IDLE = 0, RECORDING = 1, PAUSED = 2;

    public interface Listener { void onRecorderChanged(); }

    private static final String CHANNEL = "recorder";
    private static final int NOTIF_ID = 7;

    // Quality presets: Low, Standard, High, Studio
    static final int[] RATES = {22050, 44100, 48000, 48000};
    static final int[] BITRATES = {64000, 128000, 192000, 320000};
    static final int[] CHANNELS = {1, 1, 1, 2};

    static volatile int state = IDLE;
    static volatile String currentPath;
    static Listener listener;
    private static RecorderService instance;

    private MediaRecorder recorder;
    private File file;
    private long accumulated;
    private long segmentStart;

    public static File dir(Context c) {
        File d = c.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        if (d == null) d = new File(c.getFilesDir(), "recordings");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static long elapsedMs() {
        RecorderService s = instance;
        if (s == null || state == IDLE) return 0;
        if (state == RECORDING) return s.accumulated + (SystemClock.elapsedRealtime() - s.segmentStart);
        return s.accumulated;
    }

    public static int amplitude() {
        RecorderService s = instance;
        if (s == null || s.recorder == null || state != RECORDING) return 0;
        try {
            return s.recorder.getMaxAmplitude();
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_START.equals(a)) {
            start(intent.getIntExtra(EXTRA_QUALITY, 2), intent.getIntExtra(EXTRA_SOURCE, 0));
        } else if (ACTION_PAUSE.equals(a)) {
            pause();
        } else if (ACTION_RESUME.equals(a)) {
            resume();
        } else if (ACTION_STOP.equals(a)) {
            finish(false);
        } else if (ACTION_DISCARD.equals(a)) {
            finish(true);
        } else if (state == IDLE) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void start(int quality, int source) {
        if (state != IDLE) return;
        quality = Math.max(0, Math.min(RATES.length - 1, quality));
        state = RECORDING;
        accumulated = 0;
        segmentStart = SystemClock.elapsedRealtime();
        Notification n = build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIF_ID, n);
        }

        String name = "Rec_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".m4a";
        file = new File(dir(this), name);
        currentPath = file.getAbsolutePath();

        boolean ok = tryStart(quality, source);
        if (!ok && source != 0) ok = tryStart(quality, 0); // fall back to the standard mic
        if (!ok && quality == 3) ok = tryStart(2, 0);      // fall back from stereo
        if (!ok) {
            state = IDLE;
            if (file != null) file.delete();
            Toast.makeText(this, "Could not start the microphone. Is another app using it?", Toast.LENGTH_LONG).show();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            notifyListener();
            return;
        }
        segmentStart = SystemClock.elapsedRealtime();
        updateNotification();
        notifyListener();
    }

    private static int sourceId(int index) {
        switch (index) {
            case 1: return MediaRecorder.AudioSource.VOICE_RECOGNITION;
            case 2: return MediaRecorder.AudioSource.UNPROCESSED;
            case 3: return MediaRecorder.AudioSource.CAMCORDER;
            default: return MediaRecorder.AudioSource.MIC;
        }
    }

    private boolean tryStart(int quality, int source) {
        releaseRecorder();
        try {
            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(sourceId(source));
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioChannels(CHANNELS[quality]);
            recorder.setAudioSamplingRate(RATES[quality]);
            recorder.setAudioEncodingBitRate(BITRATES[quality]);
            recorder.setOutputFile(file.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            return true;
        } catch (Exception e) {
            releaseRecorder();
            return false;
        }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
    }

    private void pause() {
        if (state != RECORDING || recorder == null) return;
        try {
            recorder.pause();
        } catch (Exception e) {
            return;
        }
        accumulated += SystemClock.elapsedRealtime() - segmentStart;
        state = PAUSED;
        updateNotification();
        notifyListener();
    }

    private void resume() {
        if (state != PAUSED || recorder == null) return;
        try {
            recorder.resume();
        } catch (Exception e) {
            return;
        }
        segmentStart = SystemClock.elapsedRealtime();
        state = RECORDING;
        updateNotification();
        notifyListener();
    }

    private void finish(boolean discard) {
        if (recorder == null) {
            state = IDLE;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            notifyListener();
            return;
        }
        boolean ok = true;
        try {
            recorder.stop();
        } catch (RuntimeException e) {
            ok = false; // happens when the recording is too short to contain data
        }
        try { recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        if (file != null) {
            if (!ok || discard) {
                file.delete();
                if (!discard) Toast.makeText(this, "Recording too short, not saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Saved: " + file.getName(), Toast.LENGTH_SHORT).show();
            }
        }
        state = IDLE;
        accumulated = 0;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        notifyListener();
    }

    private void notifyListener() {
        Listener l = listener;
        if (l != null) l.onRecorderChanged();
    }

    private PendingIntent servicePi(String action, int req) {
        Intent i = new Intent(this, RecorderService.class).setAction(action);
        return PendingIntent.getService(this, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build() {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        boolean rec = state != PAUSED;
        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat_mic);

        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_mic)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(openPi)
                .setContentTitle(rec ? "Recording" : "Paused");
        if (rec) {
            b.setUsesChronometer(true).setShowWhen(true).setWhen(System.currentTimeMillis() - elapsedMs());
        } else {
            b.setShowWhen(false).setContentText("Elapsed " + Util.fmt(elapsedMs()));
        }
        b.addAction(new Notification.Action.Builder(icon, rec ? "Pause" : "Resume",
                servicePi(rec ? ACTION_PAUSE : ACTION_RESUME, 1)).build());
        b.addAction(new Notification.Action.Builder(icon, "Stop & save", servicePi(ACTION_STOP, 2)).build());
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private void updateNotification() {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, build());
    }

    @Override
    public void onDestroy() {
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
        state = IDLE;
        instance = null;
        notifyListener();
        super.onDestroy();
    }
}
